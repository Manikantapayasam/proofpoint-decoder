# proofpoint-decoder
---Working
1)Available only for chrome browser.
2) This extension will work on proofpoint v2 encoded URL's.

---How to install?
1)Extract PP-Decoder-Extension.Zip file .
2)Open chrome setting -> More Tools -> Extension.
3)Enable Developer Mode in the right corner.
4)Then click on Load Unpacked it will ask the path, give the PP-Decoder-Extension folder .
5)we will see icon "P" in the browser toolbar.

---How to use?
1)Right click on the proof point link.
2)We will be able to see an option "Decode PP URL " .
3)Click on that option, we will get a dialogue box with final URL.
4)Click on "OK"/click Enter , displayed URL will be copied to clipboard.
